const auth = firebase.auth();

const signedIn = document.getElementById('signedIn')
const signedOut = document.getElementById('signedOut')

const signOutBtn = document.getElementById('signedin')