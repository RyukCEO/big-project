const express = require('express')
const app = express()
const mongoose = require('mongoose')
const fs = require('fs')
const bodyParser = require('body-parser')
const User = require('./model/user')
const crypto = require('crypto')
const bcrypt = require('bcryptjs')
const JwtStrategy = require('passport-jwt')

const JWT_SECRET ='dsadadsasadsadsdas'


const authRoute = require('./routes/auth');
const { response } = require('express');
const { userInfo } = require('os')

mongoose.connect('mongodb+srv://quax:Jz278988@cluster0.id76b.mongodb.net/quax?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true
})
app.listen(3000)

app.use(express.static('cssfiles'));
app.use(express.static(__dirname + '/cssfiles'));


app.get('/login', (req,res) => {
    res.sendFile(__dirname + '/logins/login2.html')  

});

app.get('/signup', (req,res) => {
    res.sendFile(__dirname + '/signup/signup.html')  

});






// hasing password
app.use(bodyParser.json())

app.post('/api/register', async (req,res) =>  {
    console.log(req.body)
    res.json({ status: 'ok'})
    

    const {username, password: plainTextPassword } = req.body
    //console.log(await bcrypt.hash(password, salt, 10))
    const password = await bcrypt.hash(password, salt, 10)
    if(!username || typeof username !== 'string') {
        return res.json({status: 'error', error: 'invalid username'})
    }

    if(!plainTextPassword || typeof plainTextPassword !== 'string') {
        return res.json({status: 'error', error: 'invalid password'})
    }

    if(plainTextPassword.length < 5) {
        return res.json({status: 'error', error: 'password too short'})
    }

    try {
        const response = await User.create({
            username,
            email,
            password
        })
    }catch (error){
        if (error.code === 11000) {
            return res.json({status: 'error', error:'username taken'})
        }
        throw error
    }
})





app.post('/api/login', async (req,res) => {
    const {username, password} = req.body
    const user = await User.fundOne({username, password}).lean()

    if (!user) {
        return res.json({status:'error', error: 'invalid username/password'})
    }
    if(await bcrypt.compare(password, user.password)) {
        
        const token = jwt.sign({id: user._id, username: user.username},
            JWT_SECRET)
    }
     
    

})


app.get('/logedin', (req,res) => {
    res.sendFile(__dirname + '/logedin/loggedin.html')
});

app.post('/api/logedin', async (req,res) =>  {
})